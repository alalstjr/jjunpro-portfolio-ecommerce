package com.jjunpro.shop.util;

public class ClassPathUtil {

    public static final String ADMINGROUP = "admin/shop/group";
    public static final String ADMINPRODUCT = "admin/shop/product";
    public static final String ADMINORDER = "admin/shop/order";
    public static final String ADMINACCOUNT = "admin/shop/account";
    public static final String WIDGET = "widget";
    public static final String SHOP = "shop";
}