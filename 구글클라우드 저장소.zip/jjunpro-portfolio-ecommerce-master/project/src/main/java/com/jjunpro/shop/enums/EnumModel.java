package com.jjunpro.shop.enums;

public interface EnumModel {

    String getKey();

    String getValue();
}
